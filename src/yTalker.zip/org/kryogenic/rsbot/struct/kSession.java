package org.kryogenic.rsbot.struct;

/**
 * @author: Kale
 * @date: 08/08/12
 * @version: 0.0
 */
public abstract class kSession {
}
